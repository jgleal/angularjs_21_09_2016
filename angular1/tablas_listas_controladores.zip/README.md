Uso de tablas y listas
Empleo de ng-options con objetos