Ejercicio siete
Colecciones de objetos con eventos asociados