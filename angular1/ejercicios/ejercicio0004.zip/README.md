Uso de eventos
Evento click