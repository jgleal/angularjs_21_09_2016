Ejercicio ocho
Colecciones de objetos con eventos asociados