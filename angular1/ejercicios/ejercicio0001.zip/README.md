Ejercicio uno
Uso de modelos y expresiones