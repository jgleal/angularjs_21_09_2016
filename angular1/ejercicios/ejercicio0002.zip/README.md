Uso de modelos con valores por defecto
Uso de expresiones