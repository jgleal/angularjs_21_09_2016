// Code goes here
var app = angular.module("ejercicio3",[]);
app.controller("ejercicio3Ctrl", function ($scope){
  $scope.nombre = 'Nombre uno';
});
