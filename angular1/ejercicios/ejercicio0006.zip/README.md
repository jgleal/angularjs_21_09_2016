Ejercicio seis
Uso de ng-repeat