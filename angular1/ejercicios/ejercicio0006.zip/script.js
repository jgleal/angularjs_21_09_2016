// Code goes here
var app = angular.module("repeat",[]);
app.controller("repeatCtrl",['$scope', function ($scope){
$scope.nombres=["Uno","Dos","Tres"];
}]);
