Uso de controladores
Empleando métodos