Conexión con API's REST
Uso de $http