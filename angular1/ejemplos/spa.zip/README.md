Uso de ng-route
Aplicaciones SPA