Uso de constantes
Uso de valores