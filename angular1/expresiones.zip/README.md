Uso de expresiones
Algunos tipos esenciales