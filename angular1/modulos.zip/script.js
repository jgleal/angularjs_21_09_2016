// Code goes here
var app = angular.module("primera",[]);
app.controller("primero",function ($scope){
  $scope.nombre='Nombre uno';
});
