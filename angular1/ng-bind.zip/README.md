Ejemplo ng-bind
Sin usar expresiones